import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Calendar, Users, UserCheck, Clock } from 'lucide-react'

interface StatsCardsProps {
  stats: {
    totalAbsences: number
    activeAbsences: number
    totalSubstitutes: number
    assignmentsToday: number
  }
}

export function StatsCards({ stats }: StatsCardsProps) {
  const cards = [
    {
      title: 'Total Absences',
      value: stats.totalAbsences,
      icon: Calendar,
      color: 'text-blue-600'
    },
    {
      title: 'Active Absences',
      value: stats.activeAbsences,
      icon: Clock,
      color: 'text-orange-600'
    },
    {
      title: 'Available Substitutes',
      value: stats.totalSubstitutes,
      icon: UserCheck,
      color: 'text-green-600'
    },
    {
      title: 'Assignments Today',
      value: stats.assignmentsToday,
      icon: Users,
      color: 'text-purple-600'
    }
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card) => {
        const Icon = card.icon
        return (
          <Card key={card.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {card.title}
              </CardTitle>
              <Icon className={`h-5 w-5 ${card.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{card.value}</div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}