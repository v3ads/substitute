import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatDate, formatTime } from '@/lib/utils'

interface Absence {
  id: string
  date: Date
  startTime: string
  endTime: string
  priority: 'LOW' | 'MEDIUM' | 'HIGH'
  status: 'REPORTED' | 'IN_PROGRESS' | 'COMPLETED'
  teacher: {
    firstName: string
    lastName: string
  }
}

interface RecentAbsencesProps {
  absences: Absence[]
}

export function RecentAbsences({ absences }: RecentAbsencesProps) {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'HIGH': return 'destructive'
      case 'MEDIUM': return 'default'
      case 'LOW': return 'secondary'
      default: return 'secondary'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED': return 'secondary'
      case 'IN_PROGRESS': return 'default'
      case 'REPORTED': return 'destructive'
      default: return 'secondary'
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Absences</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {absences.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No recent absences</p>
          ) : (
            absences.map((absence) => (
              <div key={absence.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <div className="font-medium">
                    {absence.teacher.firstName} {absence.teacher.lastName}
                  </div>
                  <div className="text-sm text-gray-500">
                    {formatDate(absence.date)} • {formatTime(absence.startTime)} - {formatTime(absence.endTime)}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={getPriorityColor(absence.priority)}>
                    {absence.priority}
                  </Badge>
                  <Badge variant={getStatusColor(absence.status)}>
                    {absence.status.replace('_', ' ')}
                  </Badge>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}