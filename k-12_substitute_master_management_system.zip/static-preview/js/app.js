const sampleAbsences = [
  {
    id: 'abs1',
    date: '2025-09-25',
    startTime: '08:00',
    endTime: '12:00',
    priority: 'HIGH',
    status: 'REPORTED',
    teacher: { firstName: 'Alex', lastName: 'Kim' },
    notes: 'Flu symptoms; needs coverage'
  },
  {
    id: 'abs2',
    date: '2025-09-26',
    startTime: '09:00',
    endTime: '15:00',
    priority: 'MEDIUM',
    status: 'IN_PROGRESS',
    teacher: { firstName: 'Maria', lastName: 'Lopez' },
    notes: null
  },
  {
    id: 'abs3',
    date: '2025-09-27',
    startTime: '07:30',
    endTime: '11:30',
    priority: 'LOW',
    status: 'REPORTED',
    teacher: { firstName: 'Jamie', lastName: 'Cho' },
    notes: 'Counselor unavailable; sub needed'
  }
];

function renderAbsences() {
  const container = document.getElementById('absencesList');
  container.innerHTML = '';
  sampleAbsences.forEach(abs => {
    const item = document.createElement('div');
    item.className = 'absence-item';
    item.innerHTML = `
      <div class="absence-meta">
        <span class="absence-title">${abs.teacher.firstName} ${abs.teacher.lastName}</span>
        <span class="badge" data-priority>${abs.priority}</span>
        <span class="badge" data-status>${abs.status.replace('_', ' ')}</span>
      </div>
      <div class="absence-time">${abs.date} • ${abs.startTime} - ${abs.endTime}</div>
      ${abs.notes ? `<div class="absence-notes text-muted" style="margin-top:6px">${abs.notes}</div>` : ''}
    `;
    container.appendChild(item);
  });
}

function loadTheme() {
  const stored = localStorage.getItem('sub/mock-theme');
  if (stored === 'dark') {
    document.documentElement.style.setProperty('--bg', '#111827');
    document.documentElement.style.setProperty('--text', '#f9fafb');
    document.documentElement.style.setProperty('--card', '#1f2937');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  renderAbsences();
  loadTheme();
  const btn = document.getElementById('themeToggle');
  if (btn) {
    btn.addEventListener('click', () => {
      const isDark = document.documentElement.style.getPropertyValue('--bg') === '#111827';
      if (isDark) {
        // switch to light
        document.documentElement.style.setProperty('--bg', '#f8fafc');
        document.documentElement.style.setProperty('--text', '#111827');
        document.documentElement.style.setProperty('--card', '#ffffff');
        localStorage.setItem('sub/mock-theme', 'light');
      } else {
        // switch to dark
        document.documentElement.style.setProperty('--bg', '#111827');
        document.documentElement.style.setProperty('--text', '#f9fafb');
        document.documentElement.style.setProperty('--card', '#1f2937');
        localStorage.setItem('sub/mock-theme', 'dark');
      }
    });
  }
});